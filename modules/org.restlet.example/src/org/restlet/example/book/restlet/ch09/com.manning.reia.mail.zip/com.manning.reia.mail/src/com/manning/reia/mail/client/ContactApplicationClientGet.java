package com.manning.reia.mail.client;

import org.restlet.Application;
import org.restlet.data.MediaType;
import org.restlet.ext.jackson.JacksonRepresentation;
import org.restlet.representation.Representation;
import org.restlet.resource.ClientResource;

import com.manning.reia.mail.model.Contact;

public class ContactApplicationClientGet extends Application {
	public static void main(String[] args) {
		try {
			/*ClientResource clientResource = new ClientResource(
								"http://localhost:8182/contact/1");*/
			ClientResource clientResource = new ClientResource(
								"http://localhost:8182/contact");
			Representation representation = clientResource.get(MediaType./*APPLICATION_XML*/APPLICATION_JAVA_OBJECT_GWT);
			/*Contact contact = (new JacksonRepresentation<Contact>(
							representation, Contact.class)).getObject();
			System.out.println(contact.getId()
					+" - "+contact.getLastName()+" "+contact.getFirstName());*/
			System.out.println(representation.getText());
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}
