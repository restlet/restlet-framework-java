package com.manning.reia.mail.resource;

import org.restlet.resource.Get;
import org.restlet.resource.ServerResource;

import com.manning.reia.mail.model.Contact;

public class ConverterSimpleContactServerResourceImpl extends ServerResource
							implements SimpleContactServerResource {

	@Override
	@Get
	public Contact getContact() {
		System.out.println("getContact");
		Contact contact = new Contact();
		contact.setId("1");
		contact.setFirstName("Jérôme");
		contact.setLastName("Louvel");
		return contact;
	}

	@Override
	public void storeContact(Contact contact) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteContact() {
		// TODO Auto-generated method stub
		
	}

}
