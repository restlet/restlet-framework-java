package com.manning.reia.mail.service.impl;

import com.manning.reia.mail.model.Contact;
import com.manning.reia.mail.service.ContactService;

public class ContactServiceImpl implements ContactService {

	public Contact getContact(String contactId) {
		Contact contact = new Contact();
		contact.setId("1");
		contact.setLastName("Nom");
		contact.setFirstName("Prénom");
		return contact;
	}

	public void storeContact(Contact contact) {
		System.out.println("[server] "+contact.getId()
				+" - "+contact.getLastName()+" "+contact.getFirstName());
	}

}
