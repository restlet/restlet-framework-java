package com.manning.reia.mail.resource;

import org.restlet.Application;
import org.restlet.Restlet;
import org.restlet.routing.Router;

public class ContactApplication extends Application {
	public Restlet createInboundRoot() {
		Router router = new Router(getContext());
   		/*router.attach("http://localhost:8182/contact/{id}",
   						SimpleContactServerResource.class);*/
		router.attach("/healthCheck", HealthCheckServerResource.class);
   		router.attach("/contact/{id}",
   						SimpleContactServerResource.class);
   		return router;
	}
}
