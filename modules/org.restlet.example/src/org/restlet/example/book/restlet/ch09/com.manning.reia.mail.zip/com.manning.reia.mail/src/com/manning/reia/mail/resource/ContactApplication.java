package com.manning.reia.mail.resource;

import org.restlet.Application;
import org.restlet.Restlet;
import org.restlet.Server;
import org.restlet.data.Protocol;
import org.restlet.resource.Directory;
import org.restlet.routing.Router;

public class ContactApplication extends Application {
	public Restlet createInboundRoot() {
		Router router = new Router(getContext());
   		/*router.attach("http://localhost:8182/contact/{id}",
   						SimpleContactServerResource.class);*/
   		router.attach("http://localhost:8182/contact/{id}", ConverterSimpleContactServerResourceImpl.class);
   		router.attach("http://localhost:8182/contact", ConverterSimpleContactsServerResourceImpl.class);
   		//router.attachDefault(new Directory(getContext(), "war:///"));
   		/*router.attach("/contact/{id}", ConverterSimpleContactServerResourceImpl.class);
   		router.attach("/contact", ConverterSimpleContactsServerResourceImpl.class);
   		router.attachDefault(new Directory(getContext(), "war:///"));*/
   		return router;
	}

	public static void main(String[] args) {
		try {
			Server server = new Server(Protocol.HTTP, 8182);
			server.setNext(new ContactApplication());
	        server.start();
	        Thread.sleep(106000);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}
