package com.manning.reia.mail.resource;

import org.restlet.representation.EmptyRepresentation;
import org.restlet.representation.Representation;
import org.restlet.representation.Variant;
import org.restlet.resource.Get;
import org.restlet.resource.ServerResource;

public class HealthCheckServerResource extends ServerResource {

	@Get
	public Representation healthCheck(Variant variant) {
		return new EmptyRepresentation();
	}
}
