package com.manning.reia.mail.resource;

import java.util.Map;

import org.restlet.ext.jackson.JacksonRepresentation;
import org.restlet.representation.Representation;
import org.restlet.representation.Variant;
import org.restlet.resource.Get;
import org.restlet.resource.Put;
import org.restlet.resource.ServerResource;

import com.manning.reia.mail.model.Contact;
import com.manning.reia.mail.service.ContactService;
import com.manning.reia.mail.service.impl.ContactServiceImpl;

public class SimpleContactServerResource
									extends ServerResource {
	private ContactService contactService
							= new ContactServiceImpl();

	@Get
	public Representation getContact(Variant variant) {
		System.out.println("1");
		Map<String, Object> attributes
							= getRequest().getAttributes();
		String contactId = (String) attributes.get("id");
		Contact contact = contactService.getContact(contactId);
		return new JacksonRepresentation<Contact>(contact);
	}

	@Put
	public void storeContact(
			Representation representation, Variant variant) {
		Contact contact = (new JacksonRepresentation<Contact>(
				representation, Contact.class)).getObject();
		contactService.storeContact(contact);
	}
}
