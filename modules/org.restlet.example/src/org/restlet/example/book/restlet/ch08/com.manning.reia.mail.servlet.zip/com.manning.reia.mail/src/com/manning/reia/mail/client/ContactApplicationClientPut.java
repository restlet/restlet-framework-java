package com.manning.reia.mail.client;

import org.restlet.Application;
import org.restlet.ext.jackson.JacksonRepresentation;
import org.restlet.resource.ClientResource;

import com.manning.reia.mail.model.Contact;

public class ContactApplicationClientPut extends Application {

	public static void main(String[] args) {
		try {
			ClientResource clientResource = new ClientResource(
								"http://localhost:8182/contact/1");

			Contact contact = new Contact();
			contact.setId("1");
			contact.setLastName("Nom");
			contact.setFirstName("Prénom");
			JacksonRepresentation<Contact> representation
					= new JacksonRepresentation<Contact>(contact);
			clientResource.put(representation);
		} catch(Exception ex) {}
	}
}
