package com.manning.reia.mail.resource;

import java.util.ArrayList;
import java.util.List;

import org.restlet.data.MediaType;
import org.restlet.representation.Variant;
import org.restlet.resource.ResourceException;
import org.restlet.resource.ServerResource;

import com.manning.reia.mail.model.Contact;

public class ConverterSimpleContactsServerResourceImpl extends ServerResource
							implements SimpleContactsServerResource {

	/**
	 * @see ServerResource#doInit()
	 */
	protected void doInit() throws ResourceException
	{
		super.doInit();
		//setNegotiated(true);
	  //getVariants().add(new Variant(MediaType.APPLICATION_JAVA_OBJECT_GWT));
	  //getVariants().add(new Variant(MediaType.APPLICATION_XML));
	}

	public List<Contact> getContacts() {
		List<Contact> contacts = new ArrayList<Contact>();

		Contact contact1 = new Contact();
		contact1.setId("1");
		contact1.setLastName("Louvel");
		contact1.setFirstName("Jérôme");
		contacts.add(contact1);

		Contact contact2 = new Contact();
		contact2.setId("1");
		contact2.setLastName("Boileau");
		contact2.setFirstName("Thierry");
		contacts.add(contact2);

		return contacts;
	}

}
