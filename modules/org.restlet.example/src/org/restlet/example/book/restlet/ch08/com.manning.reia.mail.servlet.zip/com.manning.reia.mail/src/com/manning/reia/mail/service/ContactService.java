package com.manning.reia.mail.service;

import com.manning.reia.mail.model.Contact;

public interface ContactService {
	Contact getContact(String contactId);
	void storeContact(Contact contact);
}
