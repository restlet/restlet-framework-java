package com.manning.reia.mail.resource;

import java.util.List;

import org.restlet.resource.Get;

import com.manning.reia.mail.model.Contact;

public interface SimpleContactsServerResource {
	@Get
	public List<Contact> getContacts();
}
